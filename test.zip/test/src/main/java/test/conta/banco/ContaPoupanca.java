package test.conta.banco;

public class ContaPoupanca extends Conta {
	
	float taxaJuros = 0.06f;

	public ContaPoupanca(Cliente cliente) {
		super(cliente);
	}

	public void imprimirExtrato() {
		System.out.println("=== Extrato Conta Poupan�a ===");
		super.imprimirInfosComuns();
	}
	
	
	/**
	 * Este metodo eh chamado so apos 1no para calcular o juros
	 */
	public void bonificarAposUmAno() {
		System.out.println("=== BONUS Apos 1 Ano ===");
		this.depositar(this.saldo * taxaJuros);
	}
	
}
