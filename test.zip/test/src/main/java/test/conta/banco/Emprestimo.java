package test.conta.banco;

public class Emprestimo {
	
	private double valor;
	private static final double taxaJuroPorMes = 0.13;
	private int nroParcelas;
	
	public double getValor() {
		return valor;
	}
	public void setValor(double valor) {
		this.valor = valor;
	}
	public int getNroParcelas() {
		return nroParcelas;
	}
	public void setNroParcelas(int nroParcelas) {
		this.nroParcelas = nroParcelas;
	}
	public static double getTaxajuropormes() {
		return taxaJuroPorMes;
	}
}
