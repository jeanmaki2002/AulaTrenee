package test.conta.banco;

public class Main {

	public static void main(String[] args) {
		
		/*
		 * Operacao 1 Abrir conta para Venilton 
		 * depositar 100reais na conta corrente, e depois 
		 * transferir 100reais na conta poupanca
		 */
		Cliente venilton = new Cliente();
		venilton.setNome("Venilton");
		
		Conta ccVenilton = new ContaCorrente(venilton);
		Conta poupancaVenilton = new ContaPoupanca(venilton);

		ccVenilton.depositar(100);
		ccVenilton.transferir(100, poupancaVenilton);
		
		//ccVenilton.imprimirExtrato();
		//poupancaVenilton.imprimirExtrato();
		
		
		/*
		 * Operacao 2 Abrir conta corrente com nome do Serge 
		 * depositar 50reais na conta corrente, pegar emprestimo de 1000 reais e 
		 * transferir 200reais na conta poupanca
		 */
		Cliente cliente = new Cliente();
		cliente.setNome("Serge");
		cliente.setAdresse("Joao dias 1015, DF");
		cliente.setCpf("123.248.586-54");
		
		Emprestimo emprestimo = new Emprestimo();
		emprestimo.setValor(1000);
		emprestimo.setNroParcelas(12);
		
		Conta conta = new ContaCorrente(cliente);
		ContaPoupanca poupanca = new ContaPoupanca(cliente);
		
		conta.depositar(50);
		conta.setEmprestimo(emprestimo);
		conta.transferir(200, poupanca);
		conta.imprimirExtrato();
		
		poupanca.imprimirExtrato();
		
		poupanca.bonificarAposUmAno();
		poupanca.imprimirExtrato();
		
	}

}
